# -*- coding: utf-8 -*-
#KONTOL KONTOL KONTOL
#PUSING NI PALA BABI
'''
INI NAMANYA CL KONTOL

MUDE
           x
             LANGIT
                         x
                            UKIW
'''
from important import *
import youtube_dl
import requests
import humanize
import html5lib
from gtts import gTTS
from bs4 import BeautifulSoup
import requests, json
import urllib, urllib3, urllib.parse
import pytz, datetime, time, timeit, livejson,asyncio, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, ctypes, urllib, traceback, tempfile, platform
from thrift import transport, protocol, server
from thrift.Thrift import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from gtts import gTTS
from datetime import timedelta, date
from datetime import datetime
from threading import Thread, activeCount
from googletrans import Translator
from Naked.toolshed.shell import execute_js
parser = argparse.ArgumentParser(description='COBA DOANG')
parser.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parser.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parser.add_argument('-p', '--password', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parser.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parser.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parser.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parser.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parser.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parser.parse_args()
listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS']
line = LINE("yuliusmantio1@gmail.com","yulius11") #Input Your Email and Password Here
#==============================
#=======================================================================================================================
myMid = line.profile.mid
settings = livejson.File('setting1.json', True, False, 4)
owner = settings["owner"]
admin = settings["admin"]
programStart = time.time()
oepoll = OEPoll(line)
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectcancel = []
tmp_text = []
lurking = {}
#ban = livejson.File('blacklist.json', True, False, 4)
silent = livejson.File('silent.json', True, False, 4)
tagmeOpen = codecs.open("tag.json","r","utf-8")

tagme = json.load(tagmeOpen)
lastseen = ({
    "find": {},
    "username": {}
})
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}
wait = {
    "limit": 2,
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "selfbot": True,
    "wblacklist": False,
    "dblacklist": False,
    "wwhitelist": False,
    "dwhitelist": False,
}
liffV1 = {
    "arLiff": True
}
bool_dict = {
    True: ['Yes', 'Active', 'Success', 'Open', 'On'],
    False: ['No', 'Not Active', 'Failed', 'Close', 'Off']
}
profile = line.getContact(myMid)
settings['myProfile']['displayName'] = profile.displayName
settings['myProfile']['statusMessage'] = profile.statusMessage
settings['myProfile']['pictureStatus'] = profile.pictureStatus
coverId = line.profileDetail['result']['objectId']
settings['myProfile']['coverId'] = coverId
if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = line.server.getJson('https://17hosting.id/default.json')
        settings.update(default_settings)
        print ('##----- LOAD DEFAULT JSON (Success) -----##')
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')
def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)
def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))
def removeCmd2(cmd, text):
	key = settings['setKey']['key']
	if settings['setKey']['status'] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def command(text):
    pesan = text.lower()
    if settings['setKey']['status']:
        if pesan.startswith(settings['setKey']['key']):
            cmd = pesan.replace(settings['setKey']['key'],'')
        else:
            cmd = 'Undefined command'
    else:
        cmd = text.lower()
    return cmd
def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')
def kick(group, target):
    try:
        line.kickoutFromGroup(group, [target])
        if target == op.param2:
            line.kickoutFromGroup(group, [target])
    except:
        pass

def cancel(group, target):
    try:
        line.cancelGroupInvitation(group, [target])
        if target == op.param2:
            line.cancelGroupInvitation(group, [target])
    except:
        pass

def invite(grup, target):
    try:
        line.findAndAddContactsByMid(target)
        line.inviteIntoGroup(grup, [target])
    except:pass
    print("NOTIF_INVITE_")

def join(group):
    try:
        line.acceptGroupInvitation(group)
    except:
        try:
            line.acceptGroupInvitation(group)
        except:
            pass

def lockqr(group):
    try:
        G = line.getGroup(group)
        G.preventedJoinByTicket = True
        asd = line.updateGroup(G)
        if asd != None:
            hlthfail
    except:
        try:
            G = line.getGroup(group)
            G.preventedJoinByTicket = True
            asd = line.updateGroup(G)
            if asd != None:
                hlthfail
        except:
            pass

def backup(group, target):
    try:
        line.inviteIntoGroup(group, [target])
        if target == op.param3:
            line.inviteIntoGroup(group, [target])
    except:
        try:
            line.inviteIntoGroup(group, [target])
            if target == settings["whitelist"]:
                line.inviteIntoGroup(group, [target])
        except:
            pass

def blacklist(target):
    if target not in admin or target not in settings["whitelist"] or target not in owner:
        settings["blacklist"].append(target)
def allowLiff3(): #LIFF TROJAN
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1638870522',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def allowLiff2(): #LIFF EATER
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1586794970',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)         
def allowLiff(): #LIFF AR
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1602687308',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def sendTemplate(to, data):
    allowLiff()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    if liffV1["arLiff"]: view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    else: view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
    
def sendTemplate3(to, data):
    allowLiff3()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1638870522-PnjreV13', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate2(to, data):
    allowLiff2()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return line.sendReplyMessage(msg.id, to,"「 Picture Not Found♪ 」")
    elif settings['changeProfileVideo']['video'] == None:
        return line.sendReplyMessage(msg.id, to,"「 Video Not Found♪ 」")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = line.genOBSParams({'oid': line.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return line.sendReplyMessage(msg.id,to,"「 Fail Update Profile♪ 」")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        line.updateProfilePicture(path_p, 'vp')
def changevideopp(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': myMid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))
def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def parsingRes(res):
    result = ''
    textt = res.split('\n')
    for text in textt:
        if True not in [text.startswith(s) for s in ['╭', '║✈︎', '│', '╰']]:
            result += '\n│ ' + text
        else:
            if text == textt[0]:
                result += text
            else:
                result += '\n' + text
    return result
def sendReplyMention(msg_id, to, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    result = '× Mention Members ×\n\n'
    mention = '@botmudebot\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '  • %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '\n× Mention Members ×\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendReplyMessage(msg_id, to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def mentionMembers2(gid, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    G = line.getGroup(gid)
    result = '╭─── [ Mentions ] ─\n'
    mention = '@botmudebot\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '├ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───[ Members ]\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(gid, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@botmudebot "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendReplyMessage(msg.id,to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def sendMention2(msg_id, to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@BOTmudeBOT "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendReplyMessage(msg_id, to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def cloneProfile(mid):
    contact = line.getContact(mid)
    profile = line.getProfile()
    profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
    line.updateProfile(profile)
    if contact.pictureStatus:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus)
        line.updateProfilePicture(pict)
    coverId = line.getProfileDetail(mid)['result']['objectId']
    line.updateProfileCoverById(coverId)
def backupProfile():
    profile = line.getContact(myMid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def debug():
    get_profile_time_start = time.time()
    get_profile = line.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_profile_took = time.time() - get_profile_time_start
    return "「 Speed 」\n • Took : %.3fms♪\n • Taken: %.5f♪" % (get_profile_took,get_profile_time)
def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    line.updateProfile(profile)
    if settings['myProfile']['pictureStatus']:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'])
        line.updateProfilePicture(pict)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd == 'mute':
      if msg._from in owner or msg._from in admin:
        if to in silent['silent']:
            line.sendReplyMessage(msg.id, to, 'you have to Mute this group\nPlease Usage Commands "unmute" ')
        else:
            silent['silent'].append(to)
            line.sendReplyMessage(msg.id, to, 'Bot cant Not Operation again♪')
    elif cmd == 'unmute':
      if msg._from in owner or msg._from in admin:
        if to not in silent['silent']:
            line.sendReplyMessage(msg.id, to, "you haven't  this group :)")
        else:
            silent['silent'].remove(to)
            line.sendReplyMessage(msg.id, to, 'Bot can Operation again♪')
    if to in silent['silent']:
        return
    if cmd == 'logout':
      if msg._from in owner or msg._from in admin:
        line.sendReplyMessage(msg.id,to, 'Selfbot will logged out')
        sys.exit('##----- PROGRAM STOPPED -----##')
    elif cmd == 'logoutdevicee':
      if msg._from in owner or msg._from in admin:
        line.logout()
        sys.exit('##----- CLIENT LOGOUT -----##')
    elif cmd == 'restart':
      if msg._from in owner or msg._from in admin:
        line.sendReplyMessage(msg.id,to, 'Bot will restarting, please wait until the bot can operate ♪')
        settings['restartPoint'] = to
        restartProgram()
#================Menu Help================
    
            
    elif cmd.startswith('help'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res += '\n⌬ {key}invite「Mention」'
        res += '\n⌬ {key}kick「Mention」'
        res += '\n⌬ {key}slain「Mention」'
        res += '\n⌬ {key}kill「Mention」'
        res += '\n⌬ {key}%s「Reply」'  % settings["changeinvites"]
        res += '\n⌬ {key}%s「Reply」' % settings["changekickr"]
        res += '\n⌬ {key}%s「Bypass」' % settings["changebypass"]
        res += '\n⌬ {key}kickall'
        res += '\n⌬ {key}cancelall'
        res += '\n⌬ {key}changepict'
        res += '\n⌬ {key}changename'
        res += '\n⌬ {key}clearbl'
        res += '\n⌬ {key}clearwl'
        res += '\n⌬ {key}blacklist'
        res += '\n⌬ {key}whitelist'
        res += '\n⌬ {key}addwl @mention'
        res += '\n⌬ {key}addbl @mention'
        if cmd == 'help':
            line.sendReplyMessage(msg.id,to, (res).format_map(SafeDict(key=setKey.title())))
#================BATAS================
    elif cmd == 'speed':
      if msg._from in owner or msg._from in admin:
            debugs = debug()
            line.sendReplyMessage(msg_id,to, debugs)
    elif cmd == "me" or text.lower() == ' me':
      if settings["selfbot"] == True:
        if msg._from in owner or msg._from in admin:
           msg.contentType = 13
           msg.contentMetadata = {'mid': msg._from}
           line.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': msg._from}, contentType=13)     
    elif cmd == 'bot':
      if msg._from in owner or msg._from in admin:
        line.sendMessageMusic(to, title=line.getContact(myMid).displayName, subText=str(line.getContact(myMid).statusMessage), url='https://line.me/ti/p/~syaukiafwan2', iconurl="http://dl.profile.line-cdn.net/{}".format(line.getContact(myMid).pictureStatus), contentMetadata={})
    elif cmd == 'runtime':
      if msg._from in owner or msg._from in admin:
        runtime = time.time() - programStart
        line.sendReplyMessage(msg.id,to, ' Bot already running on ' + format_timespan(runtime))
    elif cmd == 'cekbot':
      if msg._from in owner or msg._from in admin:
        try:line.inviteIntoGroup(to, ["u044bb8c43a67a8b6e47924550d984022"]);has = "OK"
        except:has = "NOT"
        try:line.kickoutFromGroup(to, ["u044bb8c43a67a8b6e47924550d984022"]);has1 = "OK"
        except:has1 = "NOT"
        try:line.cancelGroupInvitation(to, ["u044bb8c43a67a8b6e47924550d984022"]);has2 = "OK"
        except:has2 = "NOT"
        id = line.getProfile().userid
        try:line.findContactsByUserid(id);has3 = "OK"
        except:has3 = "NOT"
        if has == "OK":sil = "Normal"
        else:sil = "Limit"
        if has1 == "OK":sil1 = "Normal"
        else:sil1 = "Limit"
        if has2 == "OK":sil2 = "Normal"
        else:sil2 = "Limit"
        if has3 == "OK":sil3 = "Normal"
        else:sil3 = "Limit"
        ret_ += "\n⌬ Kick: {}".format(sil1)
        ret_ += "\n⌬ Invite: {}".format(sil)
        ret_ += "\n⌬ Cancel: {}".format(sil2)
        ret_ += "\n⌬ Add: {}".format(sil3)
        line.sendReplyMessage(msg_id,to, ret_)
    elif cmd == "bye":
      if msg._from in owner or msg._from in admin:
        G = line.getGroup(to)
        line.leaveGroup(to)
#========
    elif cmd == "clears":
        if msg._from in owner or msg._from in admin:
            a = os.popen('sync; echo 3 > /proc/sys/vm/drop_caches').read()
            b = os.popen('cd / && cd tmp && rm && bin').read()
            res = "Success clear cache"
            line.sendReplyMessage(msg.id, to, res)
#================Blacklist & Whitelist================
    elif cmd.startswith("addwl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["whitelist"]:
                        settings["whitelist"].append(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Added To Whitelist",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Already In Whitelist",[target])
                except:
                    pass
    elif cmd.startswith("delwl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["whitelist"]:
                        settings["whitelist"].remove(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Deleted To Whitelist",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Not In Whitelist",[target])
                except:
                    pass
    elif cmd.startswith("addbl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["blacklist"]:
                        settings["blacklist"].append(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Added To Blacklist",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Already In Blacklist",[target])
                except:
                    pass
    elif cmd.startswith("delbl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["blacklist"]:
                        settings["blacklist"].remove(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Deleted To Blacklist",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Not In Blacklist",[target])
                except:
                    pass 
    elif cmd == 'blacklist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["blacklist"]) > 0:
                            h = [a for a in settings["blacklist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Blacklist 」─';no=aa
                                else:dd = '├「 Blacklist 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendReplyMessage(msg.id,to,"gada bl tot")
    elif cmd == 'whitelist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["whitelist"]) > 0:
                            h = [a for a in settings["whitelist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Whitelist 」─';no=aa
                                else:dd = '├「 Whitelist 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendReplyMessage(msg.id,to,"gada wl tot")
    elif cmd == 'adminlist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["admin"]) > 0:
                            h = [a for a in settings["admin"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Admin 」─';no=aa
                                else:dd = '├「 Admin 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendReplyMessage(msg.id,to,"gada admin tot")
    elif cmd.startswith("delbl:"):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    blacklist = settings["blacklist"]
                                    bl = blacklist[int(number)-1]
                                    settings["blacklist"].remove(bl)
                                    line.sendReplyMentionV2(msg.id, to, "╭ Type: Del Blacklist\n╰ Target: @!",[bl])
    elif cmd.startswith("delwl:"):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    whitelist = settings["whitelist"]
                                    wl = whitelist[int(number)-1]
                                    settings["whitelist"].remove(wl)
                                    line.sendReplyMentionV2(msg.id, to, "╭ Type: Del Whitelist\n╰ Target: @!",[wl])
    elif cmd.startswith("deladmin:"):
      if msg._from in owner:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    whitelist = settings["admin"]
                                    wl = whitelist[int(number)-1]
                                    settings["admin"].remove(wl)
                                    line.sendReplyMentionV2(msg.id, to, "╭ Type: Del Admin\n╰ Target: @!",[wl])
    elif cmd == 'clearbl':
      if msg._from in owner or msg._from in admin:
                        if len(settings["blacklist"]) > 0:
                            line.sendReplyMessage(msg.id, to, " {} User\n Success Cleared Blacklist ".format(len(settings["blacklist"])))
                            settings["blacklist"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to," Doesn't Have Blacklist User ")
    elif cmd == 'clearwl':
      if msg._from in owner or msg._from in admin:
                        if len(settings["whitelist"]) > 0:
                            line.sendReplyMessage(msg.id, to, " {} User\n Success Cleared Whitelist ".format(len(settings["whitelist"])))
                            settings["whitelist"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to," Doesn't Have Whitelist User")
    elif cmd == 'clearadmin':
      if msg._from in owner or msg._from in admin:
                        if len(settings["admin"]) > 0:
                            line.sendReplyMessage(msg.id, to, " {} User\n Success Cleared Admin ".format(len(settings["admin"])))
                            settings["admin"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to," Doesn't Have Admin User")
    elif cmd == "bl on":
      if msg._from in owner or msg._from in admin:
                                wait["wblacklist"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Add ")

    elif cmd == "bl off":
      if msg._from in owner or msg._from in admin:
                                wait["dblacklist"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Delete ")
    elif cmd == "admin on":
      if msg._from in owner or msg._from in admin:
                                wait["addadmin"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Add ")

    elif cmd == "admin off":
      if msg._from in owner or msg._from in admin:
                                wait["delladmin"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Delete ")
    elif cmd == "wl on":
      if msg._from in owner or msg._from in admin:
                                wait["wwhitelist"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Add ")

    elif cmd == "wl off":
      if msg._from in owner or msg._from in admin:
                                wait["dwhitelist"] = True
                                line.sendReplyMessage(msg.id, to,"Please Send Contact To Delete ")
    elif cmd == "cek bl":
        if msg._from in owner or msg._from in admin:
                        if msg.toType == 2:
                            group = line.getGroup(to)
                            nama = [contact.mid for contact in group.members]
                            lists = []
                            for tag in settings["blacklist"]:
                                lists+=filter(lambda str: str == tag, nama)
                            if lists == []:
                                line.sendReplyMessage(msg.id, to, "ga ada babi")
                                return
                            if len(lists) > 0: 
                                h = [a for a in lists]
                                k = len(h)//20
                                for aa in range(k+1):
                                    if aa == 0:dd = '╭───[ Detect Bl ]';no=aa
                                    else:dd = '';no=aa*20
                                    msgas = dd
                                    for a in h[aa*20:(aa+1)*20]:
                                        no+=1
                                        if no == len(h):msgas+='\n├ {}. @!\n├⌬ Blacklist!!\n╰───「 Blacklist 」'.format(no)
                                        else:msgas += '\n├ {}. @!'.format(no)
                                    sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
    elif cmd == "cek wl":
        if msg._from in owner or msg._from in admin:
                        if msg.toType == 2:
                            group = line.getGroup(to)
                            nama = [contact.mid for contact in group.members]
                            lists = []
                            for tag in settings["whitelist"]:
                                lists+=filter(lambda str: str == tag, nama)
                            if lists == []:
                                line.sendReplyMessage(msg.id, to, "ga ada wl")
                                return
                            if len(lists) > 0: 
                                h = [a for a in lists]
                                k = len(h)//20
                                for aa in range(k+1):
                                    if aa == 0:dd = '╭───[ Detect wl ]';no=aa
                                    else:dd = '';no=aa*20
                                    msgas = dd
                                    for a in h[aa*20:(aa+1)*20]:
                                        no+=1
                                        if no == len(h):msgas+='\n├ {}. @!\n╰───「 Whitelist 」'.format(no)
                                        else:msgas += '\n├ {}. @!'.format(no)
                                    sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
#================Protection================
    elif cmd == "setpro":
      if msg._from in owner or msg._from in admin:
                                md = "┏━━━「 Status Protected 」\n"
                                if msg.to in settings["protectqr"]: md+="┣ QR Protection 「✔️」\n"
                                else: md+="┣ QR Protection 「❌」\n"
                                if msg.to in settings["protectjoin"]: md+="┣ Lock Join 「✔️」\n"
                                else: md+="┣ Lock Join 「❌」\n"
                                if msg.to in settings["protectkick"]: md+="┣ Lock Kick 「✔️」\n"
                                else: md+="┣ Lock Kick 「❌」\n"
                                if msg.to in settings["protectinvite"]: md+="┣ Lock Invitation 「✔️」\n"
                                else: md+="┣ Lock Invitation 「❌」\n"
                                if msg.to in settings["protectcancel"]: md+="┣ Lock Cancel 「✔️」"
                                else: md+="┣ Lock Cancel 「❌」"
                                ret_ = str(md)
                                ret_ += "\n┣━━「 Protect Command 」"
                                ret_ += "\n┣ Proqr「 On/Off 」"
                                ret_ += "\n┣ Projoin「 On/Off 」"
                                ret_ += "\n┣ Prokick「 On/Off 」"
                                ret_ += "\n┣ Proinvite「 On/Off 」"
                                ret_ += "\n┣ Procan「 On/Off 」"
                                ret_ += "\n┣ Allpro「 On/Off 」"
#================BATAS================
    elif cmd == 'abort':
      if msg._from in owner or msg._from in admin:
        aborted = False
        if to in settings['changeGroupPicture']:
            settings['changeGroupPicture'].remove(to)
            line.sendReplyMessage(msg.id,to, 'Change group picture aborted')
            aborted = True
        if settings['changePictureProfile']:
            settings['changePictureProfile'] = False
            line.sendReplyMessage(msg.id,to, 'Change picture profile aborted')
            aborted = True
        if settings['changeCoverProfile']:
            settings['changeCoverProfile'] = False
            line.sendReplyMessage(msg.id,to, 'Change cover profile aborted')
            aborted = True
        if wait["wblacklist"]:
            wait["wblacklist"] = False
            line.sendReplyMessage(msg.id,to, 'Blacklist Contact aborted')
            aborted = True
        if wait["addadmin"]:
            wait["addadmin"] = False
            line.sendReplyMessage(msg.id,to, 'Admin Contact aborted')
            aborted = True
        if wait["dblacklist"]:
            wait["dblacklist"] = False
            line.sendReplyMessage(msg.id,to, 'UnBlacklist Contact aborted')
            aborted = True
        if wait["delladmin"]:
            wait["delladmin"] = False
            line.sendReplyMessage(msg.id,to, 'UnAdmin Contact aborted')
            aborted = True
        if wait["wwhitelist"]:
            wait["wwhitelist"] = False
            line.sendReplyMessage(msg.id,to, 'Whitelist Contact aborted')
            aborted = True
        if wait["dwhitelist"]:
            wait["dwhitelist"] = False
            line.sendReplyMessage(msg.id,to, 'UnWhitelist Contact aborted')
            aborted = True
        if settings['invitekontak']:
            settings['invitekontak'] = False
            line.sendReplyMessage(msg.id,to, 'Invite contact aborted')
            aborted = True
        if not aborted:
            line.sendReplyMessage(msg.id, to, 'Failed abort, nothing to abort')
    elif cmd.startswith('error'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res += '\n • {key}Error'
        res += '\n • {key}Error Logs'
        res += '\n • {key}Error Reset'
        res += '\n • {key}Error Detail <errid>'
        if cmd == 'error':
            line.sendReplyMessage(msg.id,to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'logs':
            try:
                filee = open('errorLog.txt', 'r')
            except FileNotFoundError:
                return line.sendReplyMessage(msg.id,to, 'Failed display error logs, error logs file not found')
            errors = [err.strip() for err in filee.readlines()]
            filee.close()
            if not errors: return line.sendReplyMessage(msg.id,to, 'Failed display error logs, empty error logs')
            res = '╔═══ ☞︎︎︎ Error Logs ]'
            res += '\n║✈︎ List :'
            parsed_len = len(errors)//200+1
            no = 0
            for point in range(parsed_len):
                for error in errors[point*200:(point+1)*200]:
                    if not error: continue
                    no += 1
                    res += '\n│ %i. %s' % (no, error)
                    if error == errors[-1]:
                        res += '\n╚═══ E r r o r'
                if res:
                    if res.startswith('\n'): res = res[1:]
                    line.sendReplyMessage(msg.id,to, res)
                res = ''
        elif cond[0].lower() == 'reset':
            filee = open('errorLog.txt', 'w')
            filee.write('')
            filee.close()
            shutil.rmtree('tmp/errors/', ignore_errors=True)
            os.system('mkdir tmp/errors')
            line.sendReplyMessage(msg.id,to, 'Success reset error logs')
        elif cond[0].lower() == 'detail':
            if len(cond) < 2:
                return line.sendReplyMessage(msg.id,to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            errid = cond[1]
            if os.path.exists('tmp/errors/%s.txt' % errid):
                with open('tmp/errors/%s.txt' % errid, 'r') as f:
                    line.sendReplyMessage(msg.id,to, f.read())
            else:
                return line.sendReplyMessage(msg.id,to, 'Failed display details error, errorid not valid')
        else:
            line.sendReplyMessage(msg.id,to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif txt.startswith('rname'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        texttl = textt.lower()
        res = '{key}'
        if txt == 'rname':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('changername'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['setKey']['key'].title()
        if cmd == 'changername':
            line.sendReplyMessage(msg.id,to, parsingRes(res))
        else:
            settings['setKey']['key'] = texttl
            line.sendReplyMessage(msg.id,to, 'Success change rname to (%s)' % textt)
    elif cmd == "sider on":
      if wait["selfbot"] == True:
       if msg._from in owner or msg._from in admin:
          try:
              tz = pytz.timezone("Asia/Jakarta")
              timeNow = datetime.now(tz=tz)
              line.sendReplyMessage(msg.id,to, "Cek sider diaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
              del cctv['point'][msg.to]
              del cctv['sidermem'][msg.to]
              del cctv['cyduk'][msg.to]
          except:
              pass
          cctv['point'][msg.to] = msg.id
          cctv['sidermem'][msg.to] = ""
          cctv['cyduk'][msg.to]=True

    elif cmd == "sider off":
      if wait["selfbot"] == True:
       if msg._from in owner or msg._from in admin:
          if msg.to in cctv['point']:
              tz = pytz.timezone("Asia/Jakarta")
              timeNow = datetime.now(tz=tz)
              cctv['cyduk'][msg.to]=False
              line.sendReplyMessage(msg.id, to, "Cek sider dinonaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
          else:
              line.sendReplyMessage(msg.id, to, "Sudak tidak aktif")
    elif cmd.startswith('changename '):
      if msg._from in owner or msg._from in admin:	
        separate = text.split(' ')
        name = text.replace(separate[0] + ' ','')
        profile = line.getProfile()
        profile.displayName = str(name)
        line.updateProfile(profile)
        line.sendReplyMessage(msg.id,to, 'Success change display name, changed to `%s`' % name)
    elif cmd.startswith('changebio '):
      if msg._from in owner or msg._from in admin:
        separate = text.split(' ')
        bio = text.replace(separate[0] + ' ','')
        if len(bio) <= 500:
            profile = line.getProfile()
            profile.statusMessage = bio
            line.updateProfile(profile)
            line.sendReplyMessage(msg.id,to, 'Success change status message, changed to `%s`' % bio)
        else:
            line.sendReplyMessage(msg.id,to, 'Failed change status message, the length of the bio cannot be more than 500')
    elif cmd.startswith("changekickr:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changekickr:", text)
        if len(string) <= 10000000000:
            settings['changekickr'] = string
            line.sendReplyMessage(msg.id,to, 'Success change kick reply to `%s`' % string)
        else:
            line.sendReplyMessage(msg.id,to, 'Failed change kick reply to `%s`' % string)
    elif cmd.startswith("changeinvites:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changeinvites:", text)
        if len(string) <= 10000000000:
            settings['changeinvites'] = string
            line.sendReplyMessage(msg.id,to, 'Success change invite reply to `%s`' % string)
        else:
            line.sendReplyMessage(msg.id,to, 'Failed change invite reply to `%s`' % string)
    elif cmd.startswith("changebypass:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changebypass:", text)
        if len(string) <= 10000000000:
            settings['changebypass'] = string
            line.sendReplyMessage(msg.id,to, 'Success change bypass to `%s`' % string)
        else:
            line.sendReplyMessage(msg.id,to, 'Failed change bypass to `%s`' % string)
    elif cmd.startswith("changetagall:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changetagall:", text)
        if len(string) <= 10000000000:
            settings['changetagall'] = string
            line.sendReplyMessage(msg.id,to, 'Success change tagall to `%s`' % string)
        else:
            line.sendReplyMessage(msg.id,to, 'Failed change tagall to `%s`' % string)
    elif cmd == "changepict":
      if msg._from in owner or msg._from in admin:
        settings['changePictureProfile'] = True
        line.sendReplyMessage(msg.id,to, 'Please send the image to set in picture profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changecover":
      if msg._from in owner or msg._from in admin:
        settings['changeCoverProfile'] = True
        line.sendReplyMessage(msg.id,to, 'Please send the image to set in cover profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changevp":
      if msg._from in owner or msg._from in admin:
        settings["changevp"] = True
        line.sendReplyMessage(msg_id, to, "Kirim video nya")
    elif cmd == "invite on":
      if msg._from in owner or msg._from in admin:
        settings["invitekontak"] = True
        line.sendReplyMessage(msg.id,to,"Type: Invite Contact♪\n • Detail: Invite Via Contact\n • Status: Waiting for Contact\n • Please send a Contact")
    elif cmd.startswith("getmid "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           ret_ = ""
           for ls in lists:
               ret_ += "{}".format(str(ls))
           line.generateReplyMessage(msg.id)
           line.sendReplyMessage(msg.id, to, str(ret_))    
    elif cmd.startswith("getpict "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           for ls in lists:
               path = "http://dl.profile.line.naver.jp/" + line.getContact(ls).pictureStatus
               line.generateReplyMessage(msg.id)
               line.sendReplyImageWithURL(msg.id, to, str(path))
    elif cmd.startswith("getvideo "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           for ls in lists:
               contact = line.getContact(ls)
               if contact.videoProfile == None:
                   continue
               path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
               line.generateReplyMessage(msg.id)
               line.sendVideoWithURL(to, str(path))
    elif cmd.startswith("getcover "):
      if msg._from in owner or msg._from in admin:
       if line != None:
           if 'MENTION' in msg.contentMetadata.keys()!= None:
               names = re.findall(r'@(\w+)', text)
               mention = ast.literal_eval(msg.contentMetadata['MENTION'])
               mentionees = mention['MENTIONEES']
               lists = []
               for mention in mentionees:
                   if mention["M"] not in lists:
                       lists.append(mention["M"])
               for ls in lists:
                   path = line.getProfileCoverURL(ls)
                   path = str(path)
                   line.generateReplyMessage(msg.id)
                   line.sendReplyImageWithURL(msg.id, to, str(path))
    elif cmd.startswith("getname "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
                for ls in lists:
                    contact = line.getContact(ls)
                    line.generateReplyMessage(msg.id)
                    line.sendReplyMessage(msg.id, to, "{}".format(str(contact.displayName)))
    elif cmd.startswith("getbio "):
       if msg._from in owner or msg._from in admin:
        if 'MENTION' in msg.contentMetadata.keys()!= None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
                for ls in lists:
                    contact = line.getContact(ls)
                    line.generateReplyMessage(msg.id)
                    line.sendReplyMessage(msg.id, to, "{}".format(str(contact.statusMessage)))
    elif cmd.startswith("getprofile "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
               for ls in lists:
                   contact = line.getContact(ls)
                   cu = line.getProfileCoverURL(ls)
                   path = str(cu)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   line.sendMessage(msg.to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                   line.sendReplyImageWithURL(msg.id,to,image)
                   line.sendReplyImageWithURL(msg.id,to,path)
    elif cmd == settings["changetagall"]:
      if msg._from in owner or msg._from in admin:
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(to)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(to)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendReplyMessage(msg.id,to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            sendReplyMention(msg_id, to, members)
    elif cmd.startswith("mentionall: "):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(":")
        num = msg.text.replace(sep[0] + ":","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        G = line.getGroup(gid)
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(gid)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(gid)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendReplyMessage(msg.id,to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            mentionMembers2(gid, members)
            line.sendReplyMessage(msg_id, to, 'Success Remote Mentionall\nIn Group: ' +  str(G.name))
            line.sendMention(to, msgas, [sender])
    elif cmd.startswith("ginfo: "):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(":")
        num = msg.text.replace(sep[0] + ":","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        group = line.getCompactGroup(gid)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Tidak Ditemukan'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'https://obs.line-scdn.net/' + group.pictureStatus
        res = " • Remote GroupInfo"
        res += '\n × User: @!'
        res += '\n × Group ID : ' + group.id
        res += '\n × Group Name : ' + group.name
        res += '\n × Group Creator : ' + gcreator
        res += '\n × Created Time : ' + created
        res += '\n × Group Member : ' + str(len(group.members))
        res += '\n × Group Pending : ' + str(pendings)
        res += '\n × QR Status : ' + qr
        res += '\n × Ticket : ' + ticket
        line.sendReplyImageWithURL(msg_id, to, path)
        if ccreator:
            line.sendReplyMessage(msg_id, to, None, contentMetadata={'mid': ccreator}, contentType=13)
        line.sendReplyMentionV2(msg_id, to, res, [sender])
    elif cmd == 'ginfo':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed display group info, use this command only on group chat')
        group = line.getCompactGroup(to)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Not found'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'http://dl.profile.line-cdn.net/' + group.pictureStatus
        res = ' • Group Info'
        res += '\n × ID : ' + group.id
        res += '\n × Name : ' + group.name
        res += '\n × Creator : ' + gcreator
        res += '\n × Created Time : ' + created
        res += '\n × Group Member : ' + str(len(group.members))
        res += '\n × Group Pending : ' + str(pendings)
        res += '\n × QR Status : ' + qr
        line.sendReplyImageWithURL(msg_id,to, path)
        if ccreator:
            line.sendReplyMessage(msg_id, to, None, contentMetadata={'mid': ccreator}, contentType=13)
        line.sendReplyMessage(msg.id,to, res)
    elif cmd.startswith('glist'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsJoined()
        gnames = []
        ress = []
        res = ' × Grouplist'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n   • %i. %s [%i]' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n  • %i. %s [%i]' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing Group'
        res += '\n × {key}GroupList'
        res += '\n × {key}Meluncur:「 Num 」'
        res += '\n × {key}Kickall:「 Num 」'
        res += '\n × {key}Cancelall:「 Num 」'
        res += '\n × {key}Ginfo:「 Num 」'
        res += '\n × {key}Infomem:「 Num 」'
        res += '\n × {key}Openqr:「 Num 」'
        res += '\n × {key}Closeqr:「 Num 」'
        res += '\n × {key}Inviteme:「 Num 」'
        res += '\n × {key}Leave:「 Num 」'
        ress.append(res)
        if cmd == 'glist':
          if msg._from in owner or msg._from in admin:	
            for res in ress:
                line.sendReplyMessage(msg.id,to,(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('out:'):
          if msg._from in owner or msg._from in admin:	
            texts = textt[6:].split(':')
            leaved = []
            if not gids:
                return line.sendReplyMessage(msg.id,to, 'Failed leave group, nothing group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in leaved:
                            line.sendReplyMessage(msg.id,to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendReplyMessage(msg.id,to, 'Success leave group %s' % group.name)
                    else:
                        line.sendReplyMessage(msg.id,to, 'Failed leave group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in leaved:
                            line.sendReplyMessage(msg.id,to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendReplyMessage(msg.id,to, 'Success leave group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in leaved:
                                continue
                            line.leaveGroup(gid)
                            leaved.append(gid)
                            time.sleep(0.8)
                        if to not in leaved:
                            line.sendReplyMessage(msg.id,to, 'Success leave all group ')
                    else:
                        line.sendReplyMessage(msg.id,to, 'Failed leave group with name `%s`, name not in list ' % name)
        else:
            for res in ress:
                line.sendReplyMessage(msg.id,to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('gpending'):
      if msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsInvited()
        gnames = []
        ress = []
        res = '⌬ Invitation List♪'
        res += '\n⌬ List:'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing'
        res += '\n⌬ Usage : '
        res += '\n⌬ • {key}Gpending'
        res += '\n⌬ • {key}Gpending Accept <num/name/all>'
        res += '\n⌬ • {key}Gpending Reject <num/name/all>'
        ress.append(res)
        if cmd == 'gpending':
          if msg._from in admin:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('accept '):
            texts = textt[7:].split(', ')
            accepted = []
            if not gids:
                return line.sendMessage(to, 'Failed accept group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed accept group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in accepted:
                                continue
                            line.acceptGroupInvitation(gid)
                            accepted.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success accept all invitation group ♪')
                    else:
                        line.sendMessage(to, 'Failed accept group with name `%s`, name not in list ♪' % name)
        elif texttl.startswith('reject '):
            texts = textt[7:].split(', ')
            rejected = []
            if not gids:
                return line.sendMessage(to, 'Failed reject group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed reject group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in rejected:
                                continue
                            line.rejectGroupInvitation(gid)
                            rejected.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success reject all invitation group ♪')
                    else:
                        line.sendMessage(to, 'Failed reject group with name `%s`, name not in list ♪' % name)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'memberlist':
        if msg.toType == 1:
            room = line.getRoom(to)
            members = room.contacts
        elif msg.toType == 2:
            group = line.getGroup(to)
            members = group.members
        else:
            return line.sendReplyMessage(msg.id,to, 'Failed display member list, use this command only on room or group chat')
        if not members:
            return line.sendReplyMessage(msg.id,to, 'Failed display member list, no one contact')
        res = '╭───[ Member List ]'
        parsed_len = len(members)//200+1
        no = 0
        for point in range(parsed_len):
            for member in members[point*200:(point+1)*200]:
                no += 1
                res += '\n│ %i. %s' % (no, member.displayName)
                if member == members[-1]:
                    res += '\n╰───[ Member List ]'
            if res:
                if res.startswith('\n'): res = res[1:]
                line.sendReplyMessage(msg.id,to, res)
            res = ''
    elif cmd.startswith('infomem:'):
      if msg._from in owner or msg._from in admin:
                                    separate = msg.text.split(":")
                                    number = msg.text.replace(separate[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    ret_ = ""
                                    try:
                                        group = groups[int(number)-1]
                                        G = line.getGroup(group)
                                        no = 0
                                        ret_ = ""
                                        for mem in G.members:
                                           no += 1
                                           ret_ += "\n " " "+ str(no) + ". " + mem.displayName
                                        line.sendReplyMessage(msg.id, to," Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\nTotal %i Members" % len(G.members))
                                    except:
                                           pass
    elif cmd.startswith("openqr: "):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = False
                                    line.updateGroup(G)
                                    url = line.reissueGroupTicket(group)
                                    ticket = 'Sukses Remoted Commands\nOpen qr in groups {}\nlink: https://line.me/R/ti/g/{}'.format(G.name,url)
                                    line.sendReplyMessage(msg.id,to,ticket)
    elif cmd.startswith("closeqr: "):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = True
                                    line.updateGroup(G)
                                    ticket = 'Sukses Remoted Commands\nClose qr in groups {}'.format(G.name)
                                    line.sendReplyMessage(msg.id,to,ticket)
    elif cmd == 'openqr':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed open qr')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = False
        line.updateGroup(group)
        url = line.reissueGroupTicket(group)
        ticket = 'Sukses Open qr in groups {}\nlink: https://line.me/R/ti/g/{}'.format(group.name,url)
        line.sendReplyMessage(msg.id,to, ticket)
    elif cmd == 'closeqr':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed close qr')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = True
        line.updateGroup(group)
        line.sendReplyMessage(msg.id,to, 'Success close group qr')
    elif cmd.startswith('changegn '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed change group name, use this command only on group chat')
        group = line.getCompactGroup(to)
        gname = removeCmd(text, setKey)
        if len(gname) > 50:
            return line.sendReplyMessage(msg.id,to, 'Failed change group name, the number of names cannot exceed 50')
        group.name = gname
        line.updateGroup(group)
        line.sendReplyMessage(msg.id,to, 'Success change group name to `%s`' % gname)
    elif cmd == 'changegp':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed change group picture, use this command only on group chat')
        if to not in settings['changeGroupPicture']:
            settings['changeGroupPicture'].append(to)
            line.sendReplyMessage(msg.id,to, 'Please send the image, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
        else:
            line.sendReplyMessage(msg.id,to, 'Command already active, please send the image or type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd.startswith("leave: "):
        if msg._from in owner or msg._from in admin:
            sep = msg.text.split(":")
            number = msg.text.replace(sep[0] + ":","")
            bolo = line.getGroupIdsJoined()
            try:
                group = bolo[int(number)-1+0]
                G = line.getGroup(group)
                gid = G.id
                no = 0 + 1
                line.leaveGroup(gid)
                line.sendReplyMessage(msg.id,to,"succes leave: "+str(G.name))
            except Exception as e:
                line.sendReplyMessage(msg.id,to, str(e))
#================JS DAN BYPASS================
    elif cmd == settings["changebypass"]:
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            group = line.getGroup(to)
            if group.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in group.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            mems = [a.mid for a in group.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(to, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Bypass Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Bypass Failed >_<")
    elif cmd == "kickall":
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            group = line.getGroup(to)
            if group.invitee == None:
                pends = []
            else:
            	mems = [a.mid for a in group.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(to, line.authToken)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Kickall Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Kickall Failed >_<")                    
    elif cmd == "cancelall":
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            group = line.getGroup(to)
            if group.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in group.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            cm = 'dual.js gid={} token={}'.format(to, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)  
                success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Cancelall Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Cancelall Failed >_<")
    elif cmd.startswith("meluncur: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in G.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            mems = [a.mid for a in G.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Remote Bypass Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Remote Bypass Failed >_<")
    elif cmd.startswith("kickall: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
            	mems = [a.mid for a in G.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Remote Kickall Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Remote Kickall Failed >_<")
    elif cmd.startswith("cancelall: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in G.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)  
                success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id,to,"Remote Cancelall Success")
            else:
                    line.sendReplyMessage(msg.id,to,"Remote Cancelall Failed >_<")
#========owner
    elif cmd.startswith("addadmin "):
      if msg._from in owner:
         key = eval(msg.contentMetadata["MENTION"])
         key["MENTIONEES"][0]["M"]
         targets = []
         for x in key["MENTIONEES"]:
              targets.append(x["M"])
         for target in targets:
                try:
                    if target not in admin:
                        admin.append(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Added To Admin",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Already In Admin",[target])
                except:
                    pass
    elif cmd.startswith("deladmin "):
        if msg._from in owner:
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in admin:
                        admin.remove(target)
                        line.sendReplyMentionV2(msg_id,to,"「 @! 」\nUser Deleted To Admin",[target])
                    else:
                        line.sendReplyMentionV2(msg_id,to,"User @! Not In Admin",[target])
                except:
                    pass
#========KICK========           
    elif cmd.startswith('invite '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed invite member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                except TalkException as talk_error:
                    return line.sendReplyMessage(msg.id,to, 'Failed invite members, the reason is `%s`' % talk_error.reason)
                time.sleep(0.8)
        else:
            line.sendReplyMessage(msg.id,to,)
    elif cmd.startswith('kick '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                except TalkException as talk_error:
                    return line.sendReplyMessage(msg.id,to, 'Failed kick members, the reason is `%s`' % talk_error.reason)           
        else:
            line.sendReplyMessage(msg.id,to, )
    elif cmd.startswith('slain '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendReplyMessage(msg.id,to, 'Failed vultra kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                except TalkException as talk_error:
                    return line.sendReplyMessage(msg.id,to, 'Failed vultra kick members, the reason is `%s`' % talk_error.reason)
        else:
            line.sendReplyMessage(msg.id,to,)
    elif cmd == settings["changekickr"]:
      if msg._from in owner or msg._from in admin:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.kickoutFromGroup(to, [bb._from])
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd == settings["changeinvites"]:
      if msg._from in owner or msg._from in admin:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.findAndAddContactsByMid(bb._from)
                            line.inviteIntoGroup(to, [bb._from])
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith('kill '):
      if msg._from in owner or msg._from in admin: 
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                imnoob = 'dual.js gid={} token={}'.format(to, line.authToken)
                                for x in key["MENTIONEES"]:
                                    if x["M"] not in settings["whitelist"]:
                                        imnoob += " uik={}".format(x["M"])
                                execute_js(imnoob)
    elif cmd == "purge":
      if msg._from in owner or msg._from in admin: 
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendReplyMessage(msg.id,to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                    line.kickoutFromGroup(to,[jj])
                                line.sendReplyMessage(msg.id, to,"yuhuuuu")
    elif cmd == "purgejs":
      if msg._from in owner or msg._from in admin: 
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                imnoob = 'dual.js gid={} token={}'.format(to, line.authToken)
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendReplyMessage(msg.id,to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                        imnoob += " uik={}".format(jj)
                                execute_js(imnoob)
                                line.sendReplyMessage(msg.id, to,"Blacklist has been purge")
    elif cmd.startswith("inviteme: "):
      if msg._from in owner or msg._from in admin: 
                                separate = text.split(" ")
                                num = text.replace(separate[0] + " ","")
                                groups = line.getGroupIdsJoined()
                                if groups is not None:
                                    if int(num) <= len(groups):
                                        groupid = groups[int(num) - 1]
                                        group = line.getGroup(groupid)
                                        try:
                                            line.findAndAddContactsByMid(msg._from)
                                            line.inviteIntoGroup(groupid,[msg._from])
                                            line.sendReplyMessage(msg_id,to, "「Done invite to " + group.name + "」")
                                        except Exception as e:
                                            line.sendReplyMessage(msg_id,to, str(e) + "\nMaybe, already into the group / Limit for invite")                          
#================Feature================
    elif cmd.startswith('unsend '):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(" ")
        args = msg.text.replace(sep[0] + " ","")
        mes = int(sep[1])
        M = line.getRecentMessagesV2(to, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else:
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == mes:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
    elif cmd.startswith('unsend '):
      if msg._from in owner or msg._from in admin:
        sep = text.split(" ")
        num = int(sep[1])
        numb = int(sep[2])
        sep2 = text.replace(sep[0] + ' ','')
        text = sep2.replace(sep[1] + ' ','')
        groups = line.getGroupIdsJoined()
        group = groups[int(num) - 1]
        G = line.getGroup(group)
        M = line.getRecentMessagesV2(group, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else: 
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == numb:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
        line.unsendMessage(msg.id)
        res = 'Sukses Remoted Commands'
        res += '\nTotal unsend {} message.'.format(len(MId))
        res += '\nIn Group :' + G.name
        line.sendReplyMessage(msg.id, to, res)
    elif cmd.startswith("spamtag "):
      if msg._from in owner or msg._from in admin:
            dan = text.split(" ")
            num = int(dan[1])
            text = " Spamtag \nBerhasil {} Spamtag".format(str(dan[1]))
            if 'MENTION' in msg.contentMetadata.keys()!= None:
                names = re.findall(r'@(\w+)', text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                lists = []
                for mention in mentionees:
                    if mention["M"] not in lists:
                        lists.append(mention["M"])
                for ls in lists:
                    for var in range(0,num):
                        sendMention(to, "@!", [ls])
                line.sendReplyMessage(msg.id,to, text)
                line.sendReplyMessage(msg.id, to, str(text.replace(spam[0] + " " + spam[1] + " ","")))
def executeOp(op):
    try:
        print ('++ Operation : ( %i ) %s' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' ')))
        if op.type == 5:
           if settings['autoAdd']['status']:
#                 line.findAndAddContactsByMid(op.param1)
            if settings['autoAdd']['reply']:
                if '@!' not in settings['autoAdd']['message']:
                    line.sendMessage(op.param1, settings['autoAdd']['message'])
                else:
                    line.sendMentionV2(op.param1, settings['autoAdd']['message'], [op.param1])
        if op.type == 11 or op.type == 122:
            if op.param1 in settings["protectqr"]:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                            settings["blacklist"].append(op.param2)
                            line.reissueGroupTicket(op.param1)
                            X = line.getCompactGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.updateGroup(X)
                            line.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass
        if op.type == 13 or op.type == 124:
            if settings['autoJoin']['status'] and myMid in op.param3:
                mude00 = threading.Thread(target=join, args=(op.param1,)).start()
                if settings['autoJoin']['reply']:
                    if '@!' not in settings['autoJoin']['message']:
                        line.sendMessage(op.param1, settings['autoJoin']['message'])
                    else:
                        line.sendMentionV2(op.param1, settings['autoJoin']['message'], [op.param2])
            if op.param3 in settings["blacklist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        anu = line.getCompactGroup(op.param1)
                        if anu.invitee is not None:
                            pipo = [a.mid for a in anu.invitee]
                            for target in pipo:
                                if target in op.param3:
                                    try:
                                        line.kickoutFromGroup(op.param1,[op.param2])
                                        line.cancelGroupInvitation(op.param1,[target])
                                    except:
                                        pass
                    except:pass
                else:pass
                if op.param2 not in settings["blacklist"]:
                    if op.param2 not in settings["whitelist"]:
                        settings['blacklist'].append(op.param2)
                    else:pass
                else:pass
            if op.param1 in settings["protectinvite"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])                                         
                        except:pass
                        mbul = line.getGroup(op.param1)
                        no = 0
                        for a in mbul.invitee:
                            if a.mid in op.param3:
                                if no > 10:pass
                                else:
                                    try:
                                        no = (no+1)
                                        line.cancelGroupInvitation(op.param1,[a.mid])
                                        time.sleep(0.04)
                                    except:pass
                        for b in mbul.members:
                            if b.mid in op.param3:
                                try:
                                    line.kickoutFromGroup(op.param1,[b.mid])
                                except:pass
                    except:pass
                else:pass
        if op.type == 15 or op.type == 128:
            if settings['greet']['leave']['status']:
                if '@!' not in settings['greet']['leave']['message']:
                    line.sendMessage(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
        if op.type == 17 or op.type == 130:
            if settings['greet']['join']['status']:
                if '@!' not in settings['greet']['join']['message']:
                    line.sendMessage(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
            if op.param2 in settings["blacklist"]:
                try:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
                    group.preventedJoinByTicket = True
                    line.updateGroup(group)
                except Exception as e:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
            if op.param1 in settings["protectjoin"]:
                if op.param2 not in settings["whitelist"]:
                    settings["blacklist"].append(op.param2)
                    try:
                        if op.param3 not in settings["blacklist"]:
                        	line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 19 or op.type == 133:
          if op.param3 in myMid:
            if op.param2 not in settings["blacklist"]:
                settings["blacklist"].append(op.param2)
                group = "c4e74841bc2854665f809f508795d8409" #mid gc dapat di lihat di groupinfo
                nameGroup = line.getGroup(op.param1).name
                jam = pytz.timezone("Asia/Jakarta")
                jamSek = datetime.now(tz=jam)
                jamm = datetime.strftime(jamSek, '%d-%m-%Y')
                jammm = datetime.strftime(jamSek,'%H:%M:%S')
                contact = line.getContact(myMid)
                kiker = line.getContact(op.param2)
                res = "╭───[ Notifikasi Kick ]"
                res += "\n├ In Group: {}".format(nameGroup)
                res += "\n├ Date: {}".format(jamm)
                res += "\n├ Time: {}".format(jammm)
                res += "\n├ Victim : {}".format(contact.displayName)
                res += "\n├ Kicker: {}".format(kiker.displayName)
                res += "\n╰───[ Team Gmail™♪ ]"
                data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "{}".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "https://line.me/ti/p/~syaukiafwan2",
                                         }
                                     }
                sendTemplate(group, data)
                line.sendContact(group, op.param2)
          if op.param3 in settings["whitelist"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in admin:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in owner:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectkick"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings["blacklist"].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                        except:pass
                    except:pass
        if op.type == 32 or op.type == 126:
          if op.param3 in settings["whitelist"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in admin:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in owner:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectcancel"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                        except:pass
                    except:pass
        if op.type == 55:
            if op.param2 in settings["blacklist"]:
                try:
                    mude12 = threading.Thread(target=kick, args=(op.param1, op.param2)).start()
                except:pass
        if op.type == 55:
            if op.param1 in read["readPoint"]:
                if op.param2 not in read["readMember"][op.param1]:
                    read["readMember"][op.param1].append(op.param2)

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = line.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n " + Name
                        teambotmaxZ={'previewUrl': "http://dl.profile.line-cdn.net/"+line.getContact(op.param2).picturePath, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': 'do you want to join the chat?', 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': line.getContact(op.param2).displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+op.param2,'MSG_SENDER_NAME':  line.getContact(op.param2).displayName,}
                        line.sendMessage(op.param1, line.getContact(op.param2).displayName, teambotmaxZ, 19)
        if op.type == 25:
            print ("++ Operation : ( 25 ) SEND MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
                if text.lower() == 'rechat':
                    line.removeAllMessages(op.param2)
                    line.sendReplyMessage(msg.id,to, "Allchat deleted")
        if op.type in [22,24]:
            line.sendMessage(op.param1,"Jangan Invite MC kontol!!")
            line.leaveRoom(op.param1)
        if op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            cmd      = command(text)
            setKey   = settings['setKey']['key'] if settings['setKey']['status'] else ''
            if text in tmp_text:
                return tmp_text.remove(text)
            if msg.contentType == 0:
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendReplyMessage(msg.id,to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendReplyMessage(msg.id,to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendReplyMessage(msg.id,to, 'Success join to group ' + group.name)
                try:
                    executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey)
                except TalkException as talk_error:
                    logError(talk_error)
                    if talk_error.code in [7, 8, 20]:
                        sys.exit(1)
                    line.sendReplyMessage(msg.id,to, 'Execute command error, ' + str(talk_error))
                    time.sleep(3)
                except Exception as error:
                    logError(error)
                    line.sendReplyMessage(msg.id,to, 'Execute command error, ' + str(error))
                    time.sleep(3)
            elif msg.contentType == 1: # Content type is image
                if settings['changePictureProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/picture.jpg')
                    line.updateProfilePicture(path)
                    line.sendReplyMessage(msg.id,to, 'Success change picture profile')
                    settings['changePictureProfile'] = False
                elif settings['changeCoverProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/cover.jpg')
                    line.updateProfileCover(path)
                    line.sendReplyMessage(msg.id,to, 'Success change cover profile')
                    settings['changeCoverProfile'] = False
                elif to in settings['changeGroupPicture'] and msg.toType == 2:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/grouppicture.jpg')
                    line.updateGroupPicture(to, path)
                    line.sendReplyMessage(msg.id,to, 'Success change group picture')
                    settings['changeGroupPicture'].remove(to)
            elif msg.contentType == 2: #content type video
                if settings["changevp"] == True:
                    contact = line.getProfile()
                    pict = "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                    path = line.downloadFileURL(pict)
                    path1 = line.downloadObjectMsg(msg_id)
                    settings["changevp"] = False
                    changevideopp(path, path1)
                    line.sendReplyMessage(msg.id,to, "Success change Video Profile")
            elif msg.contentType == 13: # Content type is contact
                if settings['checkContact']:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendReplyMessage(msg.id,to, 'Failed get details contact with mid ' + mid)
                    res = '' + mid
                    line.sendReplyMessage(msg.id,to, parsingRes(res))
                if settings['invitekontak']:
                    mid = msg.contentMetadata['mid']
                    try:
                        G = line.getGroup(to)
                        contact = line.getContact(mid)
                        line.findAndAddContactsByMid(mid)
                        line.inviteIntoGroup(to, [mid])
                        settings["invitekontak"] = False
                    except:
                        return line.sendReplyMessage(msg.id,to, 'Failed Invite contact with mid ' + mid)
                    else:
                            line.sendReplyMentionV2(msg.id, to,'Type: Invite Contact♪\n • Status: Success Invite @!',[mid])
                if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nContact Already In Blacklist -_-")
                        wait["wblacklist"] = False
                    else:
                        settings["blacklist"].append(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nSuccess Add Contact To Blacklist ^_^")
                        wait["wblacklist"] = False
                if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        settings["blacklist"].remove(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nSuccess Delete Contact From Blacklist ^_^")
                        wait["dblacklist"] = False
                    else:
                        wait["dblacklist"] = False
                        line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nContact Not In Blacklist -_-")
                if wait["wwhitelist"] == True:
                    if msg.contentMetadata["mid"] in settings["whitelist"]:
                        line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nContact Already In Whitelist -_-")
                        wait["wwhitelist"] = False
                    else:
                        settings["whitelist"].append(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nSuccess Add Contact To Whitelist ^_^")
                        wait["wwhitelist"] = False
                if wait["dwhitelist"] == True:
                    if msg.contentMetadata["mid"] in settings["whitelist"]:
                        settings["whitelist"].remove(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nSuccess Delete Contact From Whitelist ^_^")
                        wait["dwhitelist"] = False
                    else:
                        wait["dwhitelist"] = False
                        line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nContact Not In Whitelist -_-")
                if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in settings["admin"]:
                        line.sendReplyMessage(msg.id, to,"「 Admin 」\nContact Already In Admin -_-")
                        wait["addadmin"] = False
                    else:
                        settings["admin"].append(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Admin 」\nSuccess Add Contact To Admin ^_^")
                        wait["addadmin"] = False
                if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in settings["admin"]:
                        settings["admin"].remove(msg.contentMetadata["mid"])
                        line.sendReplyMessage(msg.id, to,"「 Admin 」\nSuccess Delete Contact From Admin ^_^")
                        wait["delladmin"] = False
                    else:
                        wait["delladmin"] = False
                        line.sendReplyMessage(msg.id, to,"「 Admin 」\nContact Not In Admin -_-")
        elif op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            if settings['autoRead']:
                line.sendChatChecked(to, msg_id)
            if msg.contentType == 0:
                if msg.toType != 0 and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if myMid in mention["M"]:
                                if line.getProfile().mid in mention["M"]:
                                    if to not in tagme['ROM']:
                                        tagme['ROM'][to] = {}
                                    if sender not in tagme['ROM'][to]:
                                        tagme['ROM'][to][sender] = {}
                                    if 'msg.id' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['msg.id'] = []
                                    if 'waktu' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['waktu'] = []
                                    tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                                    tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        if msg._from not in myMid:
                            if settings["mentionkick"] == True:
                                name = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if myMid in mention["M"]:
                                        if line.getProfile().mid in mention["M"]:
                                            sendMention(to,"Ngetag sih, jadi kena kick kan @!", [msg._from])
                                            line.kickoutFromGroup(msg.to, [msg._from])
                                            break
            if msg.contentType == 0: # Content type is text
                if settings['mimic']['status']:
                    if sender in settings['mimic']['target'] and settings['mimic']['target'][sender]:
                        try:
                            line.sendReplyMessage(msg.id,to, text, msg.contentMetadata)
                            tmp_text.append(text)
                        except:
                            pass
                if settings['autoRespondMention']['status']:
                    if msg.toType in [1, 2] and 'MENTION' in msg.contentMetadata.keys() and sender != myMid and msg.contentType not in [6, 7, 9]:
                        mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = [mention['M'] for mention in mentions['MENTIONEES']]
                        if myMid in mentionees:
                            if line.getProfile().displayName in text:
                                if '@!' not in settings['autoRespondMention']['message']:
                                    line.sendReplyMessage(msg.id,to, settings['autoRespondMention']['message'])
                                else:
                                    line.sendMentionV2(to, settings['autoRespondMention']['message'], [sender])
                if settings['autoRespond']['status']:
                    if msg.toType == 0:
                        contact = line.getContact(sender)
                        if contact.attributes != 32 and 'MENTION' not in msg.contentMetadata.keys():
                            if '@!' not in settings['autoRespond']['message']:
                                line.sendReplyMessage(msg.id,to, settings['autoRespond']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoRespond']['message'], [sender])
    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)
def runningProgram():
    if settings['restartPoint'] is not None:
        try:
            line.sendMessage(settings['restartPoint'], 'Bot can operate again ♪')
        except TalkException:
            pass
        settings['restartPoint'] = None
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)
            continue
        except KeyboardInterrupt:
            sys.exit('##---- KEYBOARD INTERRUPT -----##')
        except Exception as error:
            logError(error)
            continue
        if ops:
            for op in ops:
                executeOp(op)
                oepoll.setRevision(op.revision)
if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()
